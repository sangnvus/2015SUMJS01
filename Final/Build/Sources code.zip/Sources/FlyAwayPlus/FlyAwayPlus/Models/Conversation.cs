﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FlyAwayPlus.Models
{
    public class Conversation
    {
        public int ConversationId { get; set; }
        public string DateCreated { get; set; }
    }
}