﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FlyAwayPlus.Models
{
    public class Video
    {
        public int VideoId { get; set; }
        public string Path { get; set; }
        public string DateCreated { get; set; }
    }
}