﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FlyAwayPlus.Controllers
{
    public class LookAroundController : Controller
    {
        //
        // GET: /LookAround/
        public ActionResult Index()
        {
            return View();
        }
	}
}