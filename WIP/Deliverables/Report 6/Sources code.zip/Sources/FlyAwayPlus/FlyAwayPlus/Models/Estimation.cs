﻿namespace FlyAwayPlus.Models
{
    public class Estimation
    {
        public int EstimationId { get; set; }
        public string Payment { get; set; }
        public double Price { get; set; }
        public string DateCreated { get; set; }
    }
}